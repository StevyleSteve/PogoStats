package steve.pogo.pogostats;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CSVAdapter extends ArrayAdapter<PokemonSample>{
        Context ctx;

        public CSVAdapter(Context context, int textViewResourceId){
            super(context, textViewResourceId);

            this.ctx = context;

            loadArrayFromFile();
        }

        public View getView(final int pos, View convertView, final ViewGroup parent){
            TextView mView = (TextView)convertView;

            if(null == mView){
                mView= new TextView(parent.getContext());
                mView.setTextSize(28);
            }
            mView.setText(getItem(pos).getPokename());
            return mView;
        }

    private void loadArrayFromFile() {
        try {
            InputStream is = ctx.getAssets().open("pokemon.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = reader.readLine()) !=null){
                String[] RowData = line.split(",");

                PokemonSample sample = new PokemonSample();
                sample.setId(RowData[0]);
                sample.setPokename(RowData[1]);

                this.add(sample);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
