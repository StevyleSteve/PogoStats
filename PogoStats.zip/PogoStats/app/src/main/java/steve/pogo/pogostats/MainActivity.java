package steve.pogo.pogostats;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static steve.pogo.pogostats.R.id.hp;
import static steve.pogo.pogostats.R.id.pokelist;

public class MainActivity extends AppCompatActivity {

    CSVAdapter mAdapter;
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner pokemon = (Spinner)findViewById(pokelist);

        mAdapter = new CSVAdapter(this, -1);

        pokemon.setAdapter(mAdapter);
        readPokemonData();

        ArrayAdapter<PokemonSample> adapter = new ArrayAdapter<PokemonSample>(this, android.R.layout.simple_spinner_item, pokemonsample);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner sItems = (Spinner) findViewById(R.id.pokelist);
        sItems.setAdapter(adapter);

        pokemon.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItemText = (String) parent.getItemAtPosition(position);
                // Notify the selected item text
                Toast.makeText
                        (getApplicationContext(), "Selected : " + selectedItemText, Toast.LENGTH_SHORT)
                        .show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        int i = 9;
        i = pokemon.getSelectedItemPosition();
        EditText editText = (EditText)findViewById(R.id.hp);
        editText.setText(String.valueOf(i), TextView.BufferType.EDITABLE);
    }

    private List<PokemonSample> pokemonsample = new ArrayList<>();
    private void readPokemonData() {
        InputStream is = getResources().openRawResource(R.raw.pokedex);
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, Charset.forName("UTF-8"))
        );

        String line = "";
        try {
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                PokemonSample sample = new PokemonSample();
                sample.setId(tokens[0]);
                sample.setPokename(tokens[1]);
                pokemonsample.add(sample);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
