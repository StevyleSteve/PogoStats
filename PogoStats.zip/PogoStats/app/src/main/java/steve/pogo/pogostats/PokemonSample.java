package steve.pogo.pogostats;

class PokemonSample {
    private String id;
    private String pokename;

    public String getId() {
        return id;
    }

    public String getPokename() {
        return pokename;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPokename(String pokename) {
        this.pokename = pokename;
    }

    @Override
    public String toString() {
        return  id +
                ": " + pokename;
    }
}
